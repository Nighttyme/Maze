package maze;

public class PositionNotValidException extends RuntimeException {
    
    public PositionNotValidException() {
	super();
    }
    
    public PositionNotValidException(String msg) {
	super(msg);
    }
    
    /**
     * 
     */
    private static final long serialVersionUID = 4006004488727731444L;

}	
