package maze;

import java.util.Stack;

/**
 * Notes:
 * 
 * The start and stop position are contained within the maze object. Use the
 * getStart() and getStop() methods.
 * 
 * @author Brian Rogers
 *
 */
public class MazeSolver {

	/**
	 * You need to implement this method
	 * 
	 * @param maze: The maze to be solved.
	 * @return An array of Position which stores a solution to the maze. If a
	 *         solution is not found a null value should be returned.
	 */
}

public static Position[] solve(Maze maze) {
    	Stack <Position> s = new Stack <Position>(); 
    	
    	Position pos= maze.getStart();   	
    	s.push(pos);
    	while(!s.isEmpty()) {
    	  	Position north= new Position( pos.getRow()+1, pos.getColumn());
        	Position south= new Position( pos.getRow()-1, pos.getColumn());
        	Position west= new Position( pos.getRow(), pos.getColumn()-1);
        	Position east= new Position( pos.getRow(), pos.getColumn()+1);
    		
    	if(maze.validPosition(east) && maze.getAt(east) == ' ') {
    		s.push(east);
    	} else if(maze.validPosition(west) && maze.getAt(west) == ' ') {
    		s.push(west);
    		
    	} else if(maze.validPosition(south) && maze.getAt(south) == ' ') {
    		s.push(south);
   
    	} else if(maze.validPosition(north) && maze.getAt(north) == ' '){
    		s.push(north);
    	}
    	
    	}

    	
}
